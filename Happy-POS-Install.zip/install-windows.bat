@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title Happy POS - ติดตั้งระบบ
color 0A

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║                                              ║
echo  ║        🧾 Happy POS - ตัวติดตั้ง             ║
echo  ║        สำหรับ Windows                        ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.
echo  กำลังตรวจสอบระบบ...
echo.

REM =============================================
REM ตรวจสอบว่ารันในฐานะ Administrator หรือไม่
REM =============================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] กรุณาคลิกขวาที่ไฟล์นี้ แล้วเลือก "Run as administrator"
    echo  [!] เพื่อให้ติดตั้งได้สมบูรณ์
    echo.
    pause
    exit /b 1
)

REM =============================================
REM ตรวจสอบ Node.js
REM =============================================
echo  [1/5] ตรวจสอบ Node.js...
where node >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] ไม่พบ Node.js - กำลังดาวน์โหลดและติดตั้ง...
    echo.

    REM ดาวน์โหลด Node.js LTS
    echo  กำลังดาวน์โหลด Node.js v20 LTS...
    powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-x64.msi' -OutFile '%TEMP%\nodejs-install.msi' }"

    if not exist "%TEMP%\nodejs-install.msi" (
        echo  [X] ดาวน์โหลด Node.js ไม่สำเร็จ
        echo  [!] กรุณาดาวน์โหลดเองที่ https://nodejs.org
        echo  [!] แล้วรันไฟล์นี้อีกครั้ง
        pause
        exit /b 1
    )

    echo  กำลังติดตั้ง Node.js (อาจใช้เวลา 1-2 นาที)...
    msiexec /i "%TEMP%\nodejs-install.msi" /qn /norestart

    REM รีเฟรช PATH
    set "PATH=%PATH%;C:\Program Files\nodejs"

    REM ตรวจสอบอีกครั้ง
    where node >nul 2>&1
    if %errorLevel% neq 0 (
        echo  [X] ติดตั้ง Node.js ไม่สำเร็จ
        echo  [!] กรุณาดาวน์โหลดเองที่ https://nodejs.org
        echo  [!] ติดตั้งแล้วรันไฟล์นี้อีกครั้ง
        pause
        exit /b 1
    )

    echo  [OK] ติดตั้ง Node.js สำเร็จ!
) else (
    for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
    echo  [OK] พบ Node.js %NODE_VER%
)

echo.

REM =============================================
REM ตรวจสอบว่ามีไฟล์โปรเจกต์อยู่ในโฟลเดอร์เดียวกันหรือไม่
REM =============================================
set "SCRIPT_DIR=%~dp0"
set "INSTALL_DIR=%USERPROFILE%\HappyPOS"
set "LOCAL_MODE=0"

if exist "%SCRIPT_DIR%package.json" (
    set "LOCAL_MODE=1"
    echo  [*] ตรวจพบไฟล์ Happy POS ในโฟลเดอร์นี้
    echo  [*] จะติดตั้งจากไฟล์ในเครื่อง (ไม่ต้องดาวน์โหลด)
    echo.
)

REM =============================================
REM ตรวจสอบ Git (ข้ามถ้าติดตั้งจากไฟล์ในเครื่อง)
REM =============================================
if "%LOCAL_MODE%"=="1" (
    echo  [2/5] ข้ามการติดตั้ง Git (ใช้ไฟล์ในเครื่อง)
) else (
    echo  [2/5] ตรวจสอบ Git...
    where git >nul 2>&1
    if !errorLevel! neq 0 (
        echo  [!] ไม่พบ Git - กำลังดาวน์โหลดและติดตั้ง...
        echo.

        echo  กำลังดาวน์โหลด Git...
        powershell -Command "& { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/git-for-windows/git/releases/download/v2.47.0.windows.1/Git-2.47.0-64-bit.exe' -OutFile '%TEMP%\git-install.exe' }"

        if not exist "%TEMP%\git-install.exe" (
            echo  [X] ดาวน์โหลด Git ไม่สำเร็จ
            echo  [!] กรุณาดาวน์โหลดเองที่ https://git-scm.com
            echo  [!] แล้วรันไฟล์นี้อีกครั้ง
            pause
            exit /b 1
        )

        echo  กำลังติดตั้ง Git (อาจใช้เวลา 1-2 นาที)...
        "%TEMP%\git-install.exe" /VERYSILENT /NORESTART /NOCANCEL /SP- /CLOSEAPPLICATIONS /RESTARTAPPLICATIONS

        REM รีเฟรช PATH
        set "PATH=%PATH%;C:\Program Files\Git\cmd"

        echo  [OK] ติดตั้ง Git สำเร็จ!
    ) else (
        for /f "tokens=*" %%i in ('git --version') do set GIT_VER=%%i
        echo  [OK] พบ !GIT_VER!
    )
)

echo.

REM =============================================
REM เตรียมไฟล์ Happy POS
REM =============================================
echo  [3/5] เตรียมไฟล์ Happy POS...

if "%LOCAL_MODE%"=="1" (
    REM --- โหมดติดตั้งจากไฟล์ในเครื่อง ---
    if /i "%SCRIPT_DIR:~0,-1%" == "%INSTALL_DIR%" (
        echo  [OK] กำลังรันจากโฟลเดอร์ติดตั้งอยู่แล้ว
        cd /d "%INSTALL_DIR%"
    ) else if exist "%INSTALL_DIR%\package.json" (
        echo  [OK] พบ Happy POS อยู่แล้วที่ %INSTALL_DIR%
        echo  กำลังอัปเดตไฟล์...
        robocopy "%SCRIPT_DIR%" "%INSTALL_DIR%" /E /XD node_modules .git data /XF *.db /NFL /NDL /NJH /NJS /NC /NS >nul 2>&1
        cd /d "%INSTALL_DIR%"
    ) else (
        echo  กำลังคัดลอกไฟล์ไปที่ %INSTALL_DIR%...
        robocopy "%SCRIPT_DIR%" "%INSTALL_DIR%" /E /XD node_modules .git /NFL /NDL /NJH /NJS /NC /NS >nul 2>&1
        cd /d "%INSTALL_DIR%"
    )
    echo  [OK] เตรียมไฟล์ Happy POS สำเร็จ!
) else (
    REM --- โหมดดาวน์โหลดจาก GitHub ---
    if exist "%INSTALL_DIR%\package.json" (
        echo  [OK] พบ Happy POS อยู่แล้วที่ %INSTALL_DIR%
        echo  กำลังอัปเดต...
        cd /d "%INSTALL_DIR%"
        git pull origin main 2>nul
    ) else (
        echo  กำลังดาวน์โหลดจาก GitHub...
        git clone https://github.com/happydaddy/happy-pos.git "%INSTALL_DIR%" 2>nul
        if !errorLevel! neq 0 (
            echo  [X] ดาวน์โหลดจาก GitHub ไม่สำเร็จ
            echo  [!] ลองคัดลอกไฟล์โปรเจกต์ไปที่ %INSTALL_DIR% แล้วรันอีกครั้ง
            pause
            exit /b 1
        )
        cd /d "%INSTALL_DIR%"
    )
)

echo  [OK] ดาวน์โหลด Happy POS สำเร็จ!
echo.

REM =============================================
REM ติดตั้ง Dependencies
REM =============================================
echo  [4/5] ติดตั้ง packages (อาจใช้เวลา 2-5 นาที)...
cd /d "%INSTALL_DIR%"
call npm install 2>nul

if %errorLevel% neq 0 (
    echo  [X] ติดตั้ง packages ไม่สำเร็จ
    echo  [!] ลองรันไฟล์นี้อีกครั้ง
    pause
    exit /b 1
)

echo  [OK] ติดตั้ง packages สำเร็จ!
echo.

REM =============================================
REM สร้างฐานข้อมูลเริ่มต้น
REM =============================================
echo  [5/5] สร้างฐานข้อมูลเริ่มต้น...
cd /d "%INSTALL_DIR%"
call npm run init-db 2>nul
echo  [OK] สร้างฐานข้อมูลสำเร็จ!
echo.

REM =============================================
REM สร้าง Shortcut บน Desktop
REM =============================================
echo  กำลังสร้าง shortcut บน Desktop...

set "DESKTOP=%USERPROFILE%\Desktop"
set "SHORTCUT=%DESKTOP%\Happy POS.lnk"
set "START_SCRIPT=%INSTALL_DIR%\start-happy-pos.bat"

REM สร้าง shortcut ด้วย PowerShell
powershell -Command "& { $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%START_SCRIPT%'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.Description = 'เปิด Happy POS'; $s.IconLocation = 'shell32.dll,21'; $s.Save() }"

echo  [OK] สร้าง shortcut "Happy POS" บน Desktop แล้ว!
echo.

REM =============================================
REM เสร็จสิ้น
REM =============================================
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║                                              ║
echo  ║    ✅ ติดตั้ง Happy POS สำเร็จแล้ว!          ║
echo  ║                                              ║
echo  ║    📁 ที่ตั้ง: %USERPROFILE%\HappyPOS        ║
echo  ║    🖥️  shortcut: "Happy POS" บน Desktop      ║
echo  ║                                              ║
echo  ║    วิธีเปิดใช้งาน:                           ║
echo  ║    - ดับเบิลคลิก "Happy POS" บน Desktop      ║
echo  ║    - หรือรัน start-happy-pos.bat              ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.

set /p OPEN_NOW="  ต้องการเปิด Happy POS ตอนนี้เลยไหม? (Y/N): "
if /i "%OPEN_NOW%"=="Y" (
    call "%START_SCRIPT%"
)

pause
