#!/bin/bash
# Happy POS - ตัวติดตั้งสำหรับ Mac
# ดับเบิลคลิกไฟล์นี้เพื่อติดตั้ง

set -e

# สี
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
BOLD='\033[1m'

clear

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║                                              ║"
echo "  ║        🧾 Happy POS - ตัวติดตั้ง             ║"
echo "  ║        สำหรับ Mac                            ║"
echo "  ║                                              ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""
echo -e "  ${BLUE}กำลังตรวจสอบระบบ...${NC}"
echo ""

INSTALL_DIR="$HOME/HappyPOS"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_MODE=0

# ตรวจสอบว่ามีไฟล์โปรเจกต์อยู่ในโฟลเดอร์เดียวกันหรือไม่
if [[ -f "$SCRIPT_DIR/package.json" ]]; then
    LOCAL_MODE=1
    echo "  [*] ตรวจพบไฟล์ Happy POS ในโฟลเดอร์นี้"
    echo "  [*] จะติดตั้งจากไฟล์ในเครื่อง (ไม่ต้องดาวน์โหลด)"
    echo ""
fi

# =============================================
# ฟังก์ชัน: แสดงสถานะ
# =============================================
ok() {
    echo -e "  ${GREEN}[OK]${NC} $1"
}

fail() {
    echo -e "  ${RED}[X]${NC} $1"
}

info() {
    echo -e "  ${YELLOW}[!]${NC} $1"
}

step() {
    echo -e "  ${BLUE}[$1]${NC} $2"
}

# =============================================
# 1. ตรวจสอบและติดตั้ง Homebrew
# =============================================
step "1/5" "ตรวจสอบ Homebrew..."

if ! command -v brew &>/dev/null; then
    info "ไม่พบ Homebrew - กำลังติดตั้ง..."
    echo "  (อาจมีหน้าต่างถามรหัสผ่าน - กรุณาพิมพ์รหัสผ่าน Mac แล้วกด Enter)"
    echo ""
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    # เพิ่ม Homebrew ใน PATH สำหรับ Apple Silicon
    if [[ -f "/opt/homebrew/bin/brew" ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
        echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
    fi

    if command -v brew &>/dev/null; then
        ok "ติดตั้ง Homebrew สำเร็จ!"
    else
        fail "ติดตั้ง Homebrew ไม่สำเร็จ"
        echo "  กรุณาติดตั้งเองที่ https://brew.sh แล้วรันไฟล์นี้อีกครั้ง"
        read -p "  กด Enter เพื่อปิด..."
        exit 1
    fi
else
    ok "พบ Homebrew $(brew --version | head -1)"
fi

echo ""

# =============================================
# 2. ตรวจสอบและติดตั้ง Node.js
# =============================================
step "2/5" "ตรวจสอบ Node.js..."

if ! command -v node &>/dev/null; then
    info "ไม่พบ Node.js - กำลังติดตั้งผ่าน Homebrew..."
    brew install node@20
    brew link node@20 --force --overwrite 2>/dev/null || true

    if command -v node &>/dev/null; then
        ok "ติดตั้ง Node.js สำเร็จ!"
    else
        fail "ติดตั้ง Node.js ไม่สำเร็จ"
        echo "  กรุณาดาวน์โหลดเองที่ https://nodejs.org แล้วรันไฟล์นี้อีกครั้ง"
        read -p "  กด Enter เพื่อปิด..."
        exit 1
    fi
else
    ok "พบ Node.js $(node -v)"
fi

echo ""

# =============================================
# 3. ตรวจสอบ Git (ข้ามถ้าติดตั้งจากไฟล์ในเครื่อง)
# =============================================
if [[ "$LOCAL_MODE" -eq 1 ]]; then
    step "3/5" "ข้ามการติดตั้ง Git (ใช้ไฟล์ในเครื่อง)"
else
    step "3/5" "ตรวจสอบ Git..."

    if ! command -v git &>/dev/null; then
        info "ไม่พบ Git - กำลังติดตั้ง..."
        xcode-select --install 2>/dev/null || true
        info "กรุณาติดตั้ง Xcode Command Line Tools ที่ปรากฏขึ้น"
        info "แล้วรันไฟล์นี้อีกครั้ง"
        read -p "  กด Enter เพื่อปิด..."
        exit 1
    else
        ok "พบ $(git --version)"
    fi
fi

echo ""

# =============================================
# 4. เตรียมไฟล์ Happy POS
# =============================================
step "4/5" "เตรียมไฟล์ Happy POS..."

if [[ "$LOCAL_MODE" -eq 1 ]]; then
    # --- โหมดติดตั้งจากไฟล์ในเครื่อง ---
    REAL_SCRIPT_DIR="$(cd "$SCRIPT_DIR" && pwd -P)"
    REAL_INSTALL_DIR="$(mkdir -p "$INSTALL_DIR" && cd "$INSTALL_DIR" && pwd -P)"

    if [[ "$REAL_SCRIPT_DIR" == "$REAL_INSTALL_DIR" ]]; then
        ok "กำลังรันจากโฟลเดอร์ติดตั้งอยู่แล้ว"
        cd "$INSTALL_DIR"
    elif [[ -f "$INSTALL_DIR/package.json" ]]; then
        ok "พบ Happy POS อยู่แล้วที่ $INSTALL_DIR"
        echo "  กำลังอัปเดตไฟล์..."
        rsync -a --exclude='node_modules' --exclude='.git' --exclude='data/*.db' "$SCRIPT_DIR/" "$INSTALL_DIR/"
        cd "$INSTALL_DIR"
    else
        echo "  กำลังคัดลอกไฟล์ไปที่ $INSTALL_DIR..."
        mkdir -p "$INSTALL_DIR"
        rsync -a --exclude='node_modules' --exclude='.git' "$SCRIPT_DIR/" "$INSTALL_DIR/"
        cd "$INSTALL_DIR"
    fi
    ok "เตรียมไฟล์ Happy POS สำเร็จ!"
else
    # --- โหมดดาวน์โหลดจาก GitHub ---
    if [[ -f "$INSTALL_DIR/package.json" ]]; then
        ok "พบ Happy POS อยู่แล้วที่ $INSTALL_DIR"
        echo "  กำลังอัปเดต..."
        cd "$INSTALL_DIR"
        git pull origin main 2>/dev/null || true
    else
        echo "  กำลังดาวน์โหลดจาก GitHub..."
        git clone https://github.com/happydaddy/happy-pos.git "$INSTALL_DIR" 2>/dev/null

        if [[ $? -ne 0 ]]; then
            fail "ดาวน์โหลดจาก GitHub ไม่สำเร็จ"
            info "ลองคัดลอกไฟล์โปรเจกต์ไปที่ $INSTALL_DIR แล้วรันอีกครั้ง"
            read -p "  กด Enter เพื่อปิด..."
            exit 1
        fi
        cd "$INSTALL_DIR"
    fi
fi

ok "Happy POS พร้อมแล้ว!"
echo ""

# =============================================
# 5. ติดตั้ง Dependencies + Init DB
# =============================================
step "5/5" "ติดตั้ง packages (อาจใช้เวลา 2-5 นาที)..."
cd "$INSTALL_DIR"
npm install 2>&1 | tail -3

ok "ติดตั้ง packages สำเร็จ!"
echo ""

echo "  สร้างฐานข้อมูลเริ่มต้น..."
npm run init-db 2>/dev/null || true
ok "สร้างฐานข้อมูลสำเร็จ!"
echo ""

# =============================================
# ทำให้ start script รันได้
# =============================================
chmod +x "$INSTALL_DIR/start-happy-pos.command" 2>/dev/null || true

# =============================================
# สร้าง Shortcut (Alias) บน Desktop
# =============================================
echo "  กำลังสร้าง shortcut บน Desktop..."

DESKTOP="$HOME/Desktop"
START_SCRIPT="$INSTALL_DIR/start-happy-pos.command"

# สร้าง alias/link บน Desktop
if [[ -f "$START_SCRIPT" ]]; then
    ln -sf "$START_SCRIPT" "$DESKTOP/Happy POS.command" 2>/dev/null || true
    chmod +x "$DESKTOP/Happy POS.command" 2>/dev/null || true
    ok 'สร้าง shortcut "Happy POS" บน Desktop แล้ว!'
fi

# สร้าง Application shortcut ด้วย AppleScript
osascript <<'APPLESCRIPT' 2>/dev/null || true
tell application "Finder"
    try
        make new alias file at (path to desktop) to POSIX file (POSIX path of ((system attribute "HOME") & "/HappyPOS/start-happy-pos.command"))
        set name of result to "Happy POS"
    end try
end tell
APPLESCRIPT

echo ""

# =============================================
# เสร็จสิ้น
# =============================================
echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║                                              ║"
echo "  ║    ✅ ติดตั้ง Happy POS สำเร็จแล้ว!          ║"
echo "  ║                                              ║"
echo "  ║    📁 ที่ตั้ง: ~/HappyPOS                    ║"
echo "  ║    🖥️  shortcut: \"Happy POS\" บน Desktop      ║"
echo "  ║                                              ║"
echo "  ║    วิธีเปิดใช้งาน:                           ║"
echo "  ║    - ดับเบิลคลิก \"Happy POS\" บน Desktop      ║"
echo "  ║    - หรือรัน start-happy-pos.command          ║"
echo "  ║                                              ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

read -p "  ต้องการเปิด Happy POS ตอนนี้เลยไหม? (y/n): " OPEN_NOW
if [[ "$OPEN_NOW" == "y" || "$OPEN_NOW" == "Y" ]]; then
    bash "$START_SCRIPT"
fi
