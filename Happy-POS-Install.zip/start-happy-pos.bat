@echo off
chcp 65001 >nul 2>&1
title Happy POS - กำลังเปิดระบบ...
color 0A

set "INSTALL_DIR=%USERPROFILE%\HappyPOS"

REM ถ้ารันจากโฟลเดอร์โปรเจกต์โดยตรง ให้ใช้โฟลเดอร์ปัจจุบัน
if exist "%~dp0package.json" (
    set "INSTALL_DIR=%~dp0"
)

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║                                              ║
echo  ║        🧾 Happy POS                          ║
echo  ║        กำลังเปิดระบบ...                      ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.

REM ตรวจสอบว่ามี Node.js
where node >nul 2>&1
if %errorLevel% neq 0 (
    echo  [X] ไม่พบ Node.js
    echo  [!] กรุณารัน install-windows.bat ก่อน
    pause
    exit /b 1
)

REM ตรวจสอบว่ามี node_modules
if not exist "%INSTALL_DIR%\node_modules" (
    echo  [!] ยังไม่ได้ติดตั้ง packages
    echo  กำลังติดตั้ง (อาจใช้เวลา 2-5 นาที)...
    cd /d "%INSTALL_DIR%"
    call npm install
    echo  [OK] ติดตั้ง packages สำเร็จ!
    echo.
)

REM ตรวจสอบว่า port 21300 ว่างอยู่
netstat -ano | findstr ":21300" >nul 2>&1
if %errorLevel% equ 0 (
    echo  [!] Happy POS กำลังทำงานอยู่แล้ว
    echo  กำลังเปิด browser...
    start http://localhost:21300
    timeout /t 3 >nul
    exit /b 0
)

echo  กำลังเริ่มต้น Happy POS...
echo  (อย่าปิดหน้าต่างนี้ขณะใช้งาน)
echo.
echo  ═══════════════════════════════════════════
echo   เปิด browser ไปที่: http://localhost:21300
echo   กด Ctrl+C เพื่อหยุดระบบ
echo  ═══════════════════════════════════════════
echo.

cd /d "%INSTALL_DIR%"

REM เปิด browser หลังจาก 3 วินาที
start /b cmd /c "timeout /t 4 /nobreak >nul && start http://localhost:21300"

REM เริ่ม server
call npm run dev
