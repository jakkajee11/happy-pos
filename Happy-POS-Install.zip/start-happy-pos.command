#!/bin/bash
# Happy POS - เปิดระบบ POS
# ดับเบิลคลิกไฟล์นี้เพื่อเปิด Happy POS

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

clear

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║                                              ║"
echo "  ║        🧾 Happy POS                          ║"
echo "  ║        กำลังเปิดระบบ...                      ║"
echo "  ║                                              ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

# หาตำแหน่งโปรเจกต์
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/HappyPOS"

# ถ้ารันจากโฟลเดอร์โปรเจกต์โดยตรง
if [[ -f "$SCRIPT_DIR/package.json" ]]; then
    INSTALL_DIR="$SCRIPT_DIR"
fi

# ตรวจสอบ Node.js
if ! command -v node &>/dev/null; then
    echo -e "  ${RED}[X] ไม่พบ Node.js${NC}"
    echo "  กรุณารัน install-mac.command ก่อน"
    read -p "  กด Enter เพื่อปิด..."
    exit 1
fi

# ตรวจสอบ node_modules
if [[ ! -d "$INSTALL_DIR/node_modules" ]]; then
    echo -e "  ${YELLOW}[!] ยังไม่ได้ติดตั้ง packages${NC}"
    echo "  กำลังติดตั้ง (อาจใช้เวลา 2-5 นาที)..."
    cd "$INSTALL_DIR"
    npm install
    echo -e "  ${GREEN}[OK] ติดตั้ง packages สำเร็จ!${NC}"
    echo ""
fi

# ตรวจสอบว่า port 21300 ว่างอยู่
if lsof -i :21300 &>/dev/null; then
    echo -e "  ${YELLOW}[!] Happy POS กำลังทำงานอยู่แล้ว${NC}"
    echo "  กำลังเปิด browser..."
    open "http://localhost:21300"
    sleep 2
    exit 0
fi

echo -e "  ${GREEN}กำลังเริ่มต้น Happy POS...${NC}"
echo "  (อย่าปิดหน้าต่างนี้ขณะใช้งาน)"
echo ""
echo "  ═══════════════════════════════════════════"
echo "   เปิด browser ไปที่: http://localhost:21300"
echo "   กด Ctrl+C เพื่อหยุดระบบ"
echo "  ═══════════════════════════════════════════"
echo ""

cd "$INSTALL_DIR"

# เปิด browser หลังจาก 4 วินาที
(sleep 4 && open "http://localhost:21300") &

# เริ่ม server
npm run dev
